# Bread Aimbot 2.0 Simulator

def toggle_aimbot():
    print('Aimbot para pães ativado!')

def set_aggression_level(level):
    print(f'Nível de agressividade ajustado para: {level}')

def toggle_wallhacks():
    print('Wallhacks de pães ativado!')

def toggle_radar():
    print('Radar de pães ativado!')

def toggle_jesus_mode():
    print('Modo Jesus ativado! (Você pode andar sobre água)')

def only_bread_allowed():
    print('Apenas pães permitidos!')

# Simulação das funcionalidades
print('--- Bread Aimbot 2.0 ---')
toggle_aimbot()
set_aggression_level(5)
toggle_wallhacks()
toggle_radar()
toggle_jesus_mode()
only_bread_allowed()